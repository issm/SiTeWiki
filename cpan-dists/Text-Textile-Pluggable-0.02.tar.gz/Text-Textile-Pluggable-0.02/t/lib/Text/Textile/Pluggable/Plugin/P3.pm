package Text::Textile::Pluggable::Plugin::P3;
use strict;

sub post { $_[1] . "hoge" }

1;
