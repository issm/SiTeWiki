package My::Other::Plugin::Foobar;
use strict;

sub post { $_[1] . "hogepiyo" }

1;
