package Text::Textile::Pluggable::Plugin::P4;
use strict;

sub post { $_[1] . "fuga" }

1;
